/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bhargavsharma
 */
import java.util.Scanner;
import java.util.Random;

public class GuessTheNumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int numberToGuess = random.nextInt(100) + 1; // Generate a random number between 1 and 100
        int numberOfAttempts = 0;
        boolean hasGuessedCorrectly = false;
        int maxAttempts = 10; // Limiting the number of attempts

        System.out.println("Welcome to the Guess the Number Game!");
        System.out.println("I have selected a number between 1 and 100.");
        System.out.println("You have " + maxAttempts + " attempts to guess the number.");

        while (!hasGuessedCorrectly && numberOfAttempts < maxAttempts) {
            System.out.print("Enter your guess: ");
            int playerGuess = scanner.nextInt();
            numberOfAttempts++;

            if (playerGuess < numberToGuess) {
                System.out.println("The number is higher.");
            } else if (playerGuess > numberToGuess) {
                System.out.println("The number is lower.");
            } else {
                hasGuessedCorrectly = true;
                System.out.println("Congratulations! You've guessed the number in " + numberOfAttempts + " attempts.");
            }
        }

        if (!hasGuessedCorrectly) {
            System.out.println("You've used all your attempts! The number was " + numberToGuess);
        }

        scanner.close();
    }
}
